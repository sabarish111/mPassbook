package com.example.hp_pc.mpassbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class DisplayTransactionActivity extends AppCompatActivity {
    ArrayList<String> smsMessagesList = new ArrayList<String>();
    ListView smsListView;
    ArrayAdapter arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_transaction);
        Intent intent = getIntent();
        String cardName = intent.getStringExtra(MainActivity.CARD_NAME);
        CardsManager cardsManager = new CardsManager(MainActivity.instance());

        smsListView = (ListView) findViewById(R.id.SMSList);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, smsMessagesList);
        smsListView.setAdapter(arrayAdapter);
//        smsListView.setOnItemClickListener(this);
        String str = "";
        arrayAdapter.clear();
        for(Transaction transaction: cardsManager.getAllTransactions(cardName)){
            if(transaction.getCredit() == 0.00){
                str = "Card Number:"+ cardName + "\n DateTime:" + transaction.getTime() +"\n Debited Amount:" + transaction.getDebit();
            }else {
                str = "Card Number:"+ cardName + "\n DateTime:" + transaction.getTime() +"\n Credited Amount:" + transaction.getCredit();
            }
            arrayAdapter.add(str);
        }

    }
}
