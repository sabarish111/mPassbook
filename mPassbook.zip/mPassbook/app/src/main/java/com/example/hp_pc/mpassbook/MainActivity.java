package com.example.hp_pc.mpassbook;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity implements OnItemClickListener {

    private static final int  MY_PERMISSIONS_REQUEST_READ_SMS =1;
    private static MainActivity inst;
    ArrayList<String> smsMessagesList = new ArrayList<String>();
    ListView smsListView;
    ArrayAdapter arrayAdapter;

    public static MainActivity instance() {
        return inst;
    }

    @Override
    public void onStart() {
        super.onStart();
        inst = this;
    }
    final private int REQUEST_CODE_ASK_PERMISSIONS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.TitleWhichYouWantToDisplay);
        setContentView(R.layout.activity_main);
        smsListView = (ListView) findViewById(R.id.SMSList);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, smsMessagesList);
        smsListView.setAdapter(arrayAdapter);
        smsListView.setOnItemClickListener(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Helloooo....", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        CardsManager cardsManager = new CardsManager(this);

        refreshSmsInbox(cardsManager);
    }

    public void refreshSmsInbox(CardsManager db){
        //CardsManager db = new CardsManager(this);
        String str = "";
        arrayAdapter.clear();
        for (String cardName : db.getAllCardNames()) {
            /*for(Transaction transaction: db.getAllTransactions(cardName)){
                if(transaction.getCredit() == 0.00){
                    str = "Card Number:"+ cardName + "\n DateTime:" + transaction.getTime() +"\n Debited Amount:" + transaction.getDebit();
                 }else {
                    str = "Card Number:"+ cardName + "\n DateTime:" + transaction.getTime() +"\n Credited Amount:" + transaction.getCredit();
                }
                arrayAdapter.add(str);
            }*/
            Log.i("cardnames", cardName);
  //          str = str + "," + cardName;
            arrayAdapter.add(cardName);
        }
        int duration = Toast.LENGTH_LONG;
//        Toast toast = Toast.makeText(this, str, duration);
//        toast.show();
    }
    public void updateList(final String smsMessage) {
        arrayAdapter.insert(smsMessage, 0);
        arrayAdapter.notifyDataSetChanged();
    }
    public final static String CARD_NAME = "com.example.hp_pc.myapplication";
    public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
        try {
            String[] smsMessages = smsMessagesList.get(pos).split("\n");
            String address = smsMessages[0];
            String smsMessage = "";
            for (int i = 1; i < smsMessages.length; ++i) {
                smsMessage += smsMessages[i];
            }

            String smsMessageStr = address + "\n";
  //          smsMessageStr += smsMessage;
//            Toast.makeText(this, smsMessageStr, Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, DisplayTransactionActivity.class);
            //EditText editText = (EditText) findViewById(R.id.edit_message);
            //String message = editText.getText().toString();
            intent.putExtra(CARD_NAME, smsMessageStr);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    //Calling from IncomingSms.java
    public void addCard(String cardName){
        CardsManager db_con = new CardsManager(this);
        Toast.makeText(this, "hai"+cardName, Toast.LENGTH_SHORT).show();
        db_con.addCard(cardName);
    }
    //Calling from IncomingSms.java
    public void addTransaction(String cardName, Transaction transaction){
        CardsManager db_con = new CardsManager(this);
        db_con.addTransaction(cardName, transaction);
    }
    public boolean checkForCardExistence(String lastFourDigits){
        CardsManager db_con = new CardsManager(this);
        return db_con.checkForCardExistence(lastFourDigits);
    }
    /*    public void refreshSmsInbox() {
        ContentResolver contentResolver = getContentResolver();
        Cursor smsInboxCursor = contentResolver.query(Uri.parse("content://sms/inbox"), null, null, null, null);
        int indexBody = smsInboxCursor.getColumnIndex("body");
        int indexAddress = smsInboxCursor.getColumnIndex("address");
        if (indexBody < 0 || !smsInboxCursor.moveToFirst()) return;
        arrayAdapter.clear();
        do {
            String body = smsInboxCursor.getString(indexBody);
            CharSequence txn = "transaction";
            CharSequence card = "Credit Card";
            if(body.contains(txn)==true) {
                String str = "SMS From: " + smsInboxCursor.getString(indexAddress) +
                        "\n" + body + "\n";
                arrayAdapter.add(str);
            }
        } while (smsInboxCursor.moveToNext());
    }
*/
}