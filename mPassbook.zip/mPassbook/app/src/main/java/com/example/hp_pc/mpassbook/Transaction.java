package com.example.hp_pc.mpassbook;

/**
 * Created by hp-pc on 21-09-2016.
 */
public class Transaction {
    private double debit;
    private double credit;
    private String time;
    private String date;

    public Transaction(){}

    public Transaction(String time, String date,double debit,double credit) {
        super();
        this.time = time;
        this.date = date;
        this.debit = debit;
        this.credit = credit;
    }


    public void setTime(String time){
        this.time = time;
    }
    public void setDate(String date){
        this.date = date;
    }
    public void setDebit(double debit){
        this.debit = debit;
    }
    public void setCredit(double credit){
        this.credit = credit;
    }

    public String getTime(){
        return time;
    }
    public String getDate(){
        return date;
    }
    public double getDebit(){
        return debit;
    }
    public double getCredit(){
        return credit;
    }

    @Override
    public String toString() {
        return "Transaction [time=" + time + ", date=" + date + ", credit=" + credit +", debit=" + debit + "]";
    }
}