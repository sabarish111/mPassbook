package com.example.hp_pc.mpassbook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hp-pc on 21-09-2016.
 */
public class CardsManager extends SQLiteOpenHelper {
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "CardsDB";

    //public CardsManager(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
    public CardsManager(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create cards table
        String CREATE_DB_TABLE = "CREATE TABLE cards ( " +
                "cardId TEXT PRIMARY KEY, " +
                "cardName TEXT )";

        // create cards table
        db.execSQL(CREATE_DB_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older cards table if existed
        db.execSQL("DROP TABLE IF EXISTS cards");
        // create fresh cards table
        this.onCreate(db);
    }
    // Cards table name
    private static final String TABLE_CARDS = "cards";
    public boolean checkForCardExistence(String cardId){
        String selectQuery = "SELECT  * FROM " + TABLE_CARDS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                if(cardId.equals(cursor.getString(0))){
                    db.close();
                    return true;
                }
            } while (cursor.moveToNext());
        }
        db.close();
        return false;
    }
    //cardname -> 1029
    public void addCard(String cardName){
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("cardId", cardName);
        values.put("cardName", "card"+cardName);
        db.insert("cards", // table
                null, //nullColumnHack
                values); // key/value -> keys = column names/ values = column values

        // SQL statement to create cardname table
        // cardname -> card+last 4 digits of card
        String CREATE_DB_TABLE = "CREATE TABLE "+ "card" + cardName +"( " +
                "time TEXT PRIMARY KEY, " +
                "date TEXT," +
                "debit REAL," +
                "credit REAL )";
        // create cards table
        db.execSQL(CREATE_DB_TABLE);
        db.close();
    }

    //cardname -> 1029
    public void deleteCard(String cardName){
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("cards", cardName, null);
        db.execSQL("DROP TABLE IF EXISTS " + "card" +cardName);
        db.close();
    }
    private static final String KEY_TIME = "time";
    private static final String KEY_DATE= "date";
    private static final String KEY_DEBIT = "debit";
    private static final String KEY_CREDIT = "credit";

    public void addTransaction(String cardName, Transaction transaction){
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. create ContentValues to add key "column"/value
        ContentValues values = new ContentValues();
        values.put(KEY_TIME,  transaction.getTime()); // get time
        values.put(KEY_DATE, transaction.getDate()); // get date
        values.put(KEY_DEBIT, transaction.getDebit());
        values.put(KEY_CREDIT, transaction.getCredit());
        // 3. insert
        db.insert(cardName, // table
                null, //nullColumnHack
                values); // key/value -> keys = column names/ values = column values

        // 4. close
        db.close();
    }
    public void deleteTransaction(String cardName){

    }
    public List<Transaction> getAllTransactions(String cardName) {
        List<Transaction> transactionsList = new ArrayList<Transaction>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + cardName;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Transaction transaction = new Transaction(cursor.getString(0),cursor.getString(1),Double.parseDouble(cursor.getString(2)),Double.parseDouble(cursor.getString(3)));
                transactionsList.add(transaction);
            } while (cursor.moveToNext());
        }

        // return contact list
        return transactionsList;
    }

    public List<String> getAllCardNames(){
        List<String> cardList = new ArrayList<String>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_CARDS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                cardList.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }

        // return contact list
        return cardList;
    }
}
