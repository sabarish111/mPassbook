package com.example.hp_pc.mpassbook;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by hp-pc on 29-08-2016.
 */
public class IncomingSms extends BroadcastReceiver {

    // Get the object of SmsManager
    final SmsManager sms = SmsManager.getDefault();

    public void onReceive(Context context, Intent intent) {

        // Retrieves a map of extended data from the intent.
        final Bundle bundle = intent.getExtras();

        try {

            if (bundle != null) {

                final Object[] pdusObj = (Object[]) bundle.get("pdus");

                for (int i = 0; i < pdusObj.length; i++) {

                    SmsMessage currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i]);
                    String phoneNumber = currentMessage.getDisplayOriginatingAddress();

                    String senderNum = phoneNumber;
                    String message = currentMessage.getDisplayMessageBody();
                    CharSequence txn = "transaction";
                    CharSequence using = "thank you for using";
                    CharSequence debited = "debited";
                    CharSequence credited = "credited";
                    CharSequence outstanding = "outstanding of";
                    Log.i("SmsReceiver", "senderNum: "+ senderNum + "; message: " + message);
                    String cardNum  ="";

                    if(message.toLowerCase().contains(credited)) {
                        Pattern p = Pattern.compile("INR [0-9]+.[0-9][0-9]");
                        Matcher m = p.matcher(message); // get a matcher object
                        String creditedAmount = "";
                        if (m.find()) {
                            String creditedTemp = message.substring( m.start(),m.end());
                             creditedAmount= creditedTemp.substring(4, creditedTemp.length());
                        }
                        p = Pattern.compile("X+[0-9][0-9][0-9][0-9]");
                        m = p.matcher(message); // get a matcher object
                        String lastFourDigits = "";
                        if (m.find()) {
                            cardNum = message.substring(m.start(),m.end());
                            lastFourDigits = cardNum.substring(cardNum.length()-4, cardNum.length());
                        }

                        // Show Alert
                        int duration = Toast.LENGTH_LONG;
                        Toast toast = Toast.makeText(context,
                                "senderNum: " + senderNum + ", message: " + message, duration);
                        toast.show();
                        MainActivity inst = MainActivity.instance();
//                        inst.updateList("senderNum: " + senderNum + ", message: " + message);
                        String messageText= "From: " + senderNum + "\nMessage: " + message;
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(currentMessage.getTimestampMillis());

                        int date = calendar.get(calendar.DAY_OF_MONTH);
                        int month = calendar.get(calendar.MONTH);
                        int year = calendar.get(calendar.YEAR);
                        String dateOfTxn = date + "-" + month + "-" + year ;

                        int hour = calendar.get(calendar.HOUR_OF_DAY);
                        int min = calendar.get(calendar.MINUTE);
                        int sec = calendar.get(calendar.SECOND);
                        String timeOfTxn = hour + ":" + min + ":" + sec + " " + dateOfTxn;

                        Transaction transaction = new Transaction(timeOfTxn, dateOfTxn, 0.00, Double.parseDouble(creditedAmount),messageText);
                        //CardsManager db_con = new CardsManager(inst);
                        // if(db_con.checkForCardExistence(lastFourDigits) == false){
                        if(!inst.checkForCardExistence(lastFourDigits)){
//                            db_con.addCard(lastFourDigits);
                            inst.addCard(lastFourDigits);
                        }
                        inst.addTransaction("card"+lastFourDigits, transaction);
//                        db_con.addTransaction("card"+lastFourDigits, transaction);
                        //inst.updateList("cardNum: " + lastFourDigits + "\n time: " + timeOfTxn +"\n crediedAmount:" + creditedAmount);

                    }else if(message.toLowerCase().contains(txn) || message.toLowerCase().contains(using) || message.toLowerCase().contains(debited)) {
                        Pattern p = Pattern.compile("INR [0-9]+.[0-9][0-9]");
                        Matcher m = p.matcher(message); // get a matcher object
                        String debitedAmount = "";
                        if (m.find()) {
                            String debitedTemp = message.substring(m.start(),m.end());
                            debitedAmount= debitedTemp.substring(4, debitedTemp.length());
                        }
                        p = Pattern.compile("X+[0-9][0-9][0-9][0-9]");
                        m = p.matcher(message); // get a matcher object
                        String lastFourDigits = "";
                        if (m.find()) {
                            cardNum = message.substring(m.start(),m.end());
                            lastFourDigits = cardNum.substring(cardNum.length()-4, cardNum.length());
                        }

                        // Show Alert
                        int duration = Toast.LENGTH_LONG;
                        Toast toast = Toast.makeText(context,
                                "senderNum: " + senderNum + ", message: " + message, duration);
                        toast.show();
                        MainActivity inst = MainActivity.instance();
                        String messageText= "From: " + senderNum + "\nMessage: " + message;

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(currentMessage.getTimestampMillis());

                        int date = calendar.get(calendar.DAY_OF_MONTH);
                        int month = calendar.get(calendar.MONTH);
                        int year = calendar.get(calendar.YEAR);
                        String dateOfTxn = date + "-" + month + "-" + year ;

                        int hour = calendar.get(calendar.HOUR_OF_DAY);
                        int min = calendar.get(calendar.MINUTE);
                        int sec = calendar.get(calendar.SECOND);
                        String timeOfTxn = hour + ":" + min + ":" + sec + " " + dateOfTxn;

                        Transaction transaction = new Transaction(timeOfTxn, dateOfTxn,Double.parseDouble(debitedAmount), 0.00,messageText);
                        //CardsManager db_con = new CardsManager(inst);
                       // if(db_con.checkForCardExistence(lastFourDigits) == false){
                         if(!inst.checkForCardExistence(lastFourDigits)){
                            Log.i("addIncoming",lastFourDigits);
                            inst.addCard(lastFourDigits);
                            //db_con.addCard(lastFourDigits);
                        }
                        Log.i("addTransactionIS",lastFourDigits);
                        inst.addTransaction("card"+lastFourDigits, transaction);
                        //db_con.addTransaction("card"+lastFourDigits, transaction);


                       // inst.updateList("cardNum: " + lastFourDigits + "\n time: " + timeOfTxn +"\n debitedAmount:" + debitedAmount);

                    }else if(message.contains(outstanding)){
                        String due ="";
                        String outs="";
                        Pattern p = Pattern.compile("INR [0-9]+.[0-9][0-9]");
                        Matcher m = p.matcher(message); // get a matcher object
                        if (m.find()) {
                            outs = message.substring( m.start(),m.end());
                        }
                        p = Pattern.compile("X+[0-9][0-9][0-9][0-9]");
                        m = p.matcher(message); // get a matcher object
                        if (m.find()) {
                            cardNum = message.substring(m.start(),m.end());
                        }
                        p = Pattern.compile("[0-9]0-9]-(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)-20[0-9][0-9]",Pattern.CASE_INSENSITIVE);
                        m = p.matcher(message); // get a matcher object
                        if (m.find()) {
                            due = message.substring(m.start(),m.end());
                        }
                        // Show Alert
                        String display="CardNum: " + cardNum + "\nOutstanding amount:" + outs +"\nPaymentDue:"+due;
                        int duration = Toast.LENGTH_LONG;
                        Toast toast = Toast.makeText(context,display, duration);
                        toast.show();
                        MainActivity inst = MainActivity.instance();
                        inst.updateList(display);
                    }
                } // end for loop
            } // bundle is null

        } catch (Exception e) {
            Log.e("SmsReceiver", "Exception smsReceiver" +e);

        }
    }

}
