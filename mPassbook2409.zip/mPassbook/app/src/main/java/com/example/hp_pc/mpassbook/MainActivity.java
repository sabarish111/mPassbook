package com.example.hp_pc.mpassbook;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity implements OnItemClickListener,AdapterView.OnItemLongClickListener {

    private static MainActivity inst;
    ArrayList<String> smsMessagesList = new ArrayList<String>();
    ListView smsListView;
    ArrayAdapter arrayAdapter;
    ArrayList<String> cardIdList = new ArrayList<String>();
    ArrayList<String> nickNameList = new ArrayList<String>();

    public static MainActivity instance() {
        return inst;
    }

    @Override
    public void onStart() {
        super.onStart();
        inst = this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.TitleWhichYouWantToDisplay);
        setContentView(R.layout.activity_main);
        smsListView = (ListView) findViewById(R.id.SMSList);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, smsMessagesList);
        smsListView.setAdapter(arrayAdapter);
        //single press
        smsListView.setOnItemClickListener(this);
        //Long press
//        smsListView.setOnItemLongClickListener(this);
        registerForContextMenu(smsListView);

        refreshSmsInbox();

        //Refreshing Cards details
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refreshSmsInbox();
                Snackbar.make(view, "Refreshing...", Snackbar.LENGTH_SHORT)
                        .setAction("Action", null).show();
            }
        });
    }

    public void refreshSmsInbox(){
        //CardsManager db = new CardsManager(this);
        cardIdList.clear();
        nickNameList.clear();
        int i=0;
        String str = "";
        arrayAdapter.clear();
        for(Cards cardList: CardsManager.getInstance(this).getAllCards()){
            Log.i("cards", cardList.toString());
            arrayAdapter.add(cardList.getNickName());
            cardIdList.add(i, cardList.getCardId());
            nickNameList.add(i, cardList.getNickName());
            i++;
        }
    }

    public void updateList(final String smsMessage) {
        arrayAdapter.insert(smsMessage, 0);
        arrayAdapter.notifyDataSetChanged();
    }
    public final static String CARD_NAME = "com.example.hp_pc.myapplication";
    public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
        try {
            String cardTableName = "card" + cardIdList.get(pos);
            Intent intent = new Intent(this, DisplayTransactionActivity.class);
            intent.putExtra(CARD_NAME, cardTableName);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long l) {
        try{
            Toast.makeText(this,"longPressed at"+pos,Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        if (v.getId()==R.id.SMSList) {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
            String[] menuItems = getResources().getStringArray(R.array.menu);
            for (int i = 0; i<menuItems.length; i++) {
                menu.add(Menu.NONE, i, i, menuItems[i]);
            }
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int menuItemIndex = item.getItemId();
        String[] menuItems = getResources().getStringArray(R.array.menu);
        String menuItemName = menuItems[menuItemIndex];
        final int position = info.position;
        if(menuItemName.equals("Delete")){
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which){
                        case DialogInterface.BUTTON_POSITIVE:
                            deleteCard(position);
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            break;
                    }
                }
            };
            AlertDialog.Builder ab = new AlertDialog.Builder(this);

            ab.setMessage("Are you sure to delete?").setPositiveButton("Yes", dialogClickListener)
                    .setNegativeButton("No", dialogClickListener).show();
            //deleteCard(position);
        }else if(menuItemName.equals("Edit")){
            final EditText editText = new EditText(this);
            CharSequence nickName =  nickNameList.get(position);
            editText.setText(nickName, TextView.BufferType.EDITABLE);
            editText.setSelection(editText.getText().length());
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which){
                        case DialogInterface.BUTTON_POSITIVE:
                            editNickName(position,editText.getText().toString());
                            break;
                        case DialogInterface.BUTTON_NEGATIVE:
                            break;
                    }
                }
            };
            AlertDialog.Builder ab = new AlertDialog.Builder(this);
            ab.setMessage("Edit Name of the card").setView(editText).setPositiveButton("Save", dialogClickListener)
                    .setNegativeButton("Cancel", dialogClickListener).show();

        }else{
            Toast.makeText(this, "Selected " + menuItemName + " for position " + info.position, Toast.LENGTH_LONG).show();
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
        }

        return super.onOptionsItemSelected(item);
    }
    //Calling from IncomingSms.java
    public void addCard(String cardName){
        //CardsManager db_con = new CardsManager(this);
        Toast.makeText(this, "adding card: "+cardName, Toast.LENGTH_SHORT).show();
        //db_con.addCard(cardName);
        CardsManager.getInstance(this).addCard(cardName);
        refreshSmsInbox();
    }
    //Calling from IncomingSms.java
    public void addTransaction(String cardName, Transaction transaction){
        //CardsManager db_con = new CardsManager(this);
        //db_con.addTransaction(cardName, transaction);
        CardsManager.getInstance(this).addTransaction(cardName,transaction);
    }
    public boolean checkForCardExistence(String lastFourDigits){
        //CardsManager db_con = new CardsManager(this);
        //return db_con.checkForCardExistence(lastFourDigits);
        return CardsManager.getInstance(this).checkForCardExistence(lastFourDigits);
    }
    public void deleteCard(int position){
        //Card position is 0 then  key for the card in database is 1
        //Card position is 8 then  key for the card in database is 9
        //Card position is 3 then  key for the card in database is 4
        //position++;
        Log.i("cardIdDeleting", cardIdList.get(position));
        String cardName = CardsManager.getInstance(this).deleteCard(cardIdList.get(position));
        Toast.makeText(this, cardName + " deleted", Toast.LENGTH_LONG).show();
        refreshSmsInbox();
    }

    public void editNickName(int position,String newNickName){
        String cardId = cardIdList.get(position);
        Log.i("nickNameEditing","cardId:"+cardId + ",oldNickName:" + nickNameList.get(position) + ",newNickName:"+newNickName);
        CardsManager.getInstance(this).editNickName(cardId, newNickName);
        Toast.makeText(this, "oldCardName: " + nickNameList.get(position) + "\nnewCardName: "+newNickName,Toast.LENGTH_LONG).show();
        refreshSmsInbox();
    }
/*    public String getCardTableName(int position){
        position++;
        return CardsManager.getInstance(this).getCardName(position);
    }*/
}