package com.example.hp_pc.mpassbook;

/**
 * Created by hp-pc on 21-09-2016.
 */
public class Transaction {
    private String messageText;
    private double debit;
    private double credit;
    private String time;
    private String date;

    public Transaction(){}
    public Transaction(String time, String date,double debit,double credit) {
        super();
        this.time = time;
        this.date = date;
        this.debit = debit;
        this.credit = credit;
        this.messageText = "No Content";
    }
    public Transaction(String time, String date,double debit,double credit,String messageText) {
        super();
        this.time = time;
        this.date = date;
        this.debit = debit;
        this.credit = credit;
        this.messageText = messageText;
    }


    public void setTime(String time){
        this.time = time;
    }
    public void setDate(String date){
        this.date = date;
    }
    public void setDebit(double debit){
        this.debit = debit;
    }
    public void setCredit(double credit){
        this.credit = credit;
    }
    public void setMessageText(String messageText){this.messageText = messageText;}
    public String getTime(){
        return time;
    }
    public String getDate(){
        return date;
    }
    public double getDebit(){
        return debit;
    }
    public double getCredit(){
        return credit;
    }
    public String getMessageText(){return messageText;}

    @Override
    public String toString() {
        return "Transaction [time=" + time + ", date=" + date + ", credit=" + credit +", debit=" + debit + ", messageText="+ messageText +"]";
    }
}