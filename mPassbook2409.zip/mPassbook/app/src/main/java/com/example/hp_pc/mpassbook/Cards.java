package com.example.hp_pc.mpassbook;

/**
 * Created by hp-pc on 24-09-2016.
 */
public class Cards {
    private String cardId;
    private String cardName;
    private String nickName;

    public Cards(String cardId,String cardName,String nickName){
        super();
        this.nickName = nickName;
        this.cardName = cardName;
        this.cardId = cardId;
    }
    public String getCardId() {
        return cardId;
    }

    public String getNickName() {
        return nickName;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    @Override
    public String toString() {
        return "cards [cardId:" + cardId + ",cardName:" + cardName + ",nickName:"+ nickName +"]";
    }
}
