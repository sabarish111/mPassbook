package com.example.hp_pc.mpassbook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by hp-pc on 21-09-2016.
 */
public class CardsManager extends SQLiteOpenHelper {

    private static CardsManager instance;

    public static synchronized CardsManager getInstance(Context context)
    {
        if (instance == null)
            instance = new CardsManager(context);

        return instance;
    }
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "CardsDB";
    // cards(cardId,cardName,nickName)
    //cardName always "card"+cardId
    private static final String TABLE_CARDS = "cards";
   // private static final String KEY = "key";
    private static final String KEY_CARD_ID = "cardId";
    private static final String KEY_CARD_NAME = "cardName";
    private static final String KEY_NICK_NAME = "nickName";

    //public CardsManager(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
    public CardsManager(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create cards table
        String CREATE_DB_TABLE = "CREATE TABLE cards ( " +
     //           KEY + " INTEGER PRIMARY KEY, " +
                KEY_CARD_ID + " TEXT PRIMARY KEY, " +
                KEY_CARD_NAME + " TEXT, " +
                KEY_NICK_NAME + " TEXT )";

        // create cards table
        db.execSQL(CREATE_DB_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older cards table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARDS);
        // create fresh cards table
        this.onCreate(db);
    }

    // cards(key,cardId,cardName,nickName)
    public boolean checkForCardExistence(String cardId){
        String selectQuery = "SELECT  * FROM " + TABLE_CARDS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                if(cardId.equals(cursor.getString(0))){
                    //db.close();
                    return true;
                }
            } while (cursor.moveToNext());
        }
        //db.close();
        Log.i("check",cardId);
        return false;
    }
    private static final String KEY_TIME = "time";
    private static final String KEY_DATE= "date";
    private static final String KEY_DEBIT = "debit";
    private static final String KEY_CREDIT = "credit";
    private static final String KEY_MESSAGE_TEXT = "messageText";

    //cardname -> 1029
    // cards(key,cardId,cardName,nickName)
    public void addCard(String cardName){
        // 1. get reference to writable DB
        ContentValues values = new ContentValues();
       // values.put(KEY, (numberOfCards()+1));
        values.put(KEY_CARD_ID, cardName);
        values.put(KEY_CARD_NAME, "card"+cardName);
        values.put(KEY_NICK_NAME, "card"+cardName);
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_CARDS, // table
                null, //nullColumnHack
                values); // key/value -> keys = column names/ values = column values
        Log.i("addcard",cardName);
        // SQL statement to create cardname table
        // cardname -> card+last 4 digits of card
        String CREATE_DB_TABLE = "CREATE TABLE "+ "card" + cardName +"( " +
                KEY_TIME + " TEXT PRIMARY KEY, " +
                KEY_DATE + " TEXT," +
                KEY_DEBIT + " REAL," +
                KEY_CREDIT + " REAL," +
                KEY_MESSAGE_TEXT + " TEXT)";
        // create cards table
        db.execSQL(CREATE_DB_TABLE);
        //db.close();
    }

    // cards(key,cardId,cardName,nickName)
    public void editNickName(String cardId,String newNickName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NICK_NAME, newNickName);
        String[] whereArgs = new String[]{String.valueOf(cardId)};
        int rowsUpdated = db.update(TABLE_CARDS, values, KEY_CARD_ID + "=?" , whereArgs);
        Log.i("cardsManager","CardUpdated: "+ cardId);
        //db.close();
    }

    // cards(key,cardId,cardName,nickName)
    public String deleteCard(String cardId){
        String cardName = "card" + cardId;
        String nickName = getNickName(cardId);
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
        String[] whereArgs = new String[]{String.valueOf(cardId)};
        db.delete(TABLE_CARDS, KEY_CARD_ID + "=?", whereArgs);
        db.execSQL("DROP TABLE IF EXISTS " + cardName);
        //db.close();
        return nickName;
    }


    public void addTransaction(String cardName, Transaction transaction){
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. create ContentValues to add key "column"/value
        ContentValues values = new ContentValues();
        values.put(KEY_TIME,  transaction.getTime()); // get time
        values.put(KEY_DATE, transaction.getDate()); // get date
        values.put(KEY_DEBIT, transaction.getDebit());
        values.put(KEY_CREDIT, transaction.getCredit());
        values.put(KEY_MESSAGE_TEXT, transaction.getMessageText());
        // 3. insert
        db.insert(cardName, // table
                null, //nullColumnHack
                values); // key/value -> keys = column names/ values = column values
        Log.i("insertTxn",transaction.toString());
        // 4. close
        //db.close();
    }
    public void deleteTransaction(String cardTableName,String timeStamp){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] whereArgs = new String[]{String.valueOf(timeStamp)};
        db.delete(cardTableName, KEY_TIME + "=?" , whereArgs);
    }
    public List<Transaction> getAllTransactions(String cardName) {
        List<Transaction> transactionsList = new ArrayList<Transaction>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + cardName;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                    Transaction transaction = new Transaction(cursor.getString(0), cursor.getString(1), Double.parseDouble(cursor.getString(2)), Double.parseDouble(cursor.getString(3)), cursor.getString(4));
                    transactionsList.add(transaction);

            } while (cursor.moveToNext());
        }
        cursor.close();
        //db.close();
        // return contact list
        return transactionsList;
    }

    public List<Cards> getAllCards(){
        List<Cards> cardsList = new ArrayList<Cards>();
        String selectQuery = "SELECT  * FROM " + TABLE_CARDS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Cards cards = new Cards(cursor.getString(0),cursor.getString(1),cursor.getString(2));
                cardsList.add(cards);
            } while (cursor.moveToNext());
        }
        cursor.close();
        //db.close();
        // return contact list
        return cardsList;

    }
    // cards(key,cardId,cardName,nickName)
    public List<String> getAllCardNames(){
        List<String> cardList = new ArrayList<String>();
        // Select All Query
        String selectQuery = "SELECT "+ KEY_CARD_NAME +" FROM " + TABLE_CARDS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                cardList.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        //db.close();
        // return contact list
        return cardList;
    }
    // cards(key,cardId,cardName,nickName)
    public List<String> getAllNickNames(){
        List<String> cardList = new ArrayList<String>();
        // Select All Query
        String selectQuery = "SELECT "+ KEY_NICK_NAME + " FROM " + TABLE_CARDS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                cardList.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        //db.close();
        // return contact list
        return cardList;
    }

    public List<String> getAllCardIds(){
        List<String> cardList = new ArrayList<String>();
        // Select All Query
        String selectQuery = "SELECT "+ KEY_CARD_ID + " FROM " + TABLE_CARDS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                cardList.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        //db.close();
        // return contact list
        return cardList;
    }
    // cards(key,cardId,cardName,nickName)
    public String getCardName(String cardId){
        String selectQuery = "SELECT " + KEY_CARD_NAME + " FROM " + TABLE_CARDS + " where "+KEY_CARD_ID + "=" + cardId;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        String cardName = "";
        if (cursor.moveToFirst()) {
            cardName = cursor.getString(0);
        }
        //db.close();
        // return contact list
        cursor.close();
        return cardName;
    }
    // cards(key,cardId,cardName,nickName)
    public String getNickName(String cardId){
        String selectQuery = "SELECT " + KEY_NICK_NAME + " FROM " + TABLE_CARDS + " where "+KEY_CARD_ID +"=" + cardId;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        String nickName = "";
        if(cursor.moveToFirst()){
            nickName = cursor.getString(0);
        }
        cursor.close();
        //db.close();
        // return contact list
        return nickName;
    }
    // cards(key,cardId,cardName,nickName)
    public int numberOfCards(){
        String selectQuery = "SELECT  * FROM " + TABLE_CARDS;
        int position = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                position++;
            } while (cursor.moveToNext());
        }
        cursor.close();
        //db.close();
        return position;
    }
}
