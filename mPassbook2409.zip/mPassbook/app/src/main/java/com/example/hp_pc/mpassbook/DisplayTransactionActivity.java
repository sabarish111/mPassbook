package com.example.hp_pc.mpassbook;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DisplayTransactionActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    ArrayList<String> txnMessagesList = new ArrayList<String>();
    ListView txnListView;
    ArrayAdapter arrayAdapter;
    ArrayList<String> messageTextList = new ArrayList<String>();
    ArrayList<String> messageTimeStampList = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_transaction);
        //CardsManager cardsManager = new CardsManager(MainActivity.instance());

        txnListView = (ListView) findViewById(R.id.SMSList);
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, txnMessagesList);
        txnListView.setAdapter(arrayAdapter);
        txnListView.setOnItemClickListener(this);
        registerForContextMenu(txnListView);

        showTransactions();

    }
    public void showTransactions(){
        Intent intent = getIntent();
        String cardName = intent.getStringExtra(MainActivity.CARD_NAME);
        String str = "";
        arrayAdapter.clear();
        messageTimeStampList.clear();
        messageTextList.clear();
        int i=0;
        for(Transaction transaction: CardsManager.getInstance(MainActivity.instance()).getAllTransactions(cardName)){
            if(transaction.getCredit() == 0.00){
                str = "Card Number:"+ cardName + "\n DateTime:" + transaction.getTime() +"\n Debited Amount:" + transaction.getDebit();
            }else {
                str = "Card Number:"+ cardName + "\n DateTime:" + transaction.getTime() +"\n Credited Amount:" + transaction.getCredit();
            }
            Log.i("dta", "adding message content");
            messageTextList.add(i, transaction.getMessageText());
            messageTimeStampList.add(i,transaction.getTime());
                    i++;
            Log.i("dta", "added message content");
            arrayAdapter.add(str);
        }
    }

    public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
        try {
            Toast.makeText(this, messageTextList.get(pos), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        if (v.getId()==R.id.SMSList) {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
            String[] menuItems = getResources().getStringArray(R.array.menuForTxn);
            for (int i = 0; i<menuItems.length; i++) {
                menu.add(Menu.NONE, i, i, menuItems[i]);
            }
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int menuItemIndex = item.getItemId();
        String[] menuItems = getResources().getStringArray(R.array.menuForTxn);
        String menuItemName = menuItems[menuItemIndex];
        final int position = info.position;
        if(menuItemName.equals("Delete")){
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which){
                        case DialogInterface.BUTTON_POSITIVE:
                            deleteTransaction(position);
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            break;
                    }
                }
            };
            AlertDialog.Builder ab = new AlertDialog.Builder(this);
            ab.setMessage("Are you sure to delete?").setPositiveButton("Yes", dialogClickListener)
                    .setNegativeButton("No", dialogClickListener).show();
        }
        return true;
    }

    public void deleteTransaction(int position){
        Intent intent = getIntent();
        String cardName = intent.getStringExtra(MainActivity.CARD_NAME);
        String timeStamp = messageTimeStampList.get(position);
        Log.i("dta","deleting txn of time stamp "+ timeStamp +" of the card "+ cardName);
        CardsManager.getInstance(MainActivity.instance()).deleteTransaction(cardName, timeStamp);
        Toast.makeText(this, "Transaction Deleted", Toast.LENGTH_SHORT);
        showTransactions();
    }

}
